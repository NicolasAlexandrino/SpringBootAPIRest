# Upgrade Plan: LojaAX (20260912193758)

- **Generated**: 2026-09-12 19:37:58
- **HEAD Branch**: N/A
- **HEAD Commit ID**: N/A

## Available Tools

**JDKs**
- JDK 17: not available (baseline will be skipped)
- JDK 25.0.4.1: C:\Program Files\Zulu\zulu-25\bin (required by the upgrade step)

**Build Tools**
- Maven Wrapper: 3.9.16 (detected from .mvn/wrapper/maven-wrapper.properties)
- Maven executable: **<TO_BE_INSTALLED>**? Build tool is supplied by the Maven Wrapper script in this workspace

## Guidelines

- Target Java runtime must be upgraded to the latest LTS version available in the environment.
- Preserve the existing Spring Boot 3.3.4 stack and current project structure.
- Keep the build reproducible by preferring the Maven Wrapper when present.

> Note: You can add any specific guidelines or constraints for the upgrade process here if needed, bullet points are preferred.

## Options

- Working branch: appmod/java-upgrade-20260912193758
- Run tests before and after the upgrade: true

## Upgrade Goals

- Java 17 → Java 25

## Technology Stack

| Technology/Dependency | Current | Min Compatible Version | Why Incompatible |
| ---------------------- | ------- | ---------------------- | --------------- |
| Java | 17 | 25 | User requested |
| Spring Boot | 3.3.4 | 3.5.16 | Spring Boot 3.3.4 cannot parse the Java 25 classfile format during test metadata scanning |
| Maven Wrapper | 3.9.16 | 3.9.16 | Already compatible; no wrapper upgrade required |
| Java compiler target in pom.xml | 17 | 25 | Property must be raised to meet the requested runtime target |

## Derived Upgrades

- Java 17 → Java 25 requires the project compiler level and runtime metadata to be updated from 17 to 25 in the Maven project file.
- Maven 3.9.16 is already present via the wrapper configuration and is compatible with Java 25.
- No Kotlin dependency or Gradle usage is present in this project, so no Kotlin/Gradle compatibility migration is required.

## Impact Analysis

### Subsection: Dependency Changes

| File | Dependency | Current | Action | Target | Reason |
|------|-----------|---------|--------|--------|--------|
| pom.xml | java.version | 17 | upgrade | 25 | User requested Java LTS target |
| pom.xml | spring-boot-starter-parent | 3.3.4 | upgrade | 3.5.16 | Required to consume Java 25 classfile metadata during Spring Boot test scanning |

### Subsection: Source Code Changes

| File | Location | Current | Required Change | Reason |
|------|----------|---------|------------------|--------|
| None | N/A | N/A | No source changes expected because frameworks and APIs already align with Spring Boot 3.3.4 | Java runtime metadata update only |

### Subsection: Configuration Changes

| File | Property/Setting | Current | Required Change | Reason |
|------|------------------|---------|-----------------|--------|
| pom.xml | java.version | 17 | 25 | Align the project compiler/runtime target with the latest Java LTS |

### Subsection: CI/CD Changes

| File | Location | Current | Required Change |
|------|----------|---------|----------------|
| None | N/A | N/A | No CI/CD files found in the project workspace |

### Subsection: Risks & Warnings

- Java 25 runtime availability is already confirmed in the workspace environment; no install step is needed.
- The project has no Git repository metadata, so branch/state/version-control integration will be unavailable and documented in the final summary.
- The current Spring Boot 3.3.4 framework is already compatible with the Java 25 JDK target, so no framework-level source migration is expected.

## Upgrade Steps

- Step 1: Setup Environment
  - **Rationale**: Confirm the required JDK 25 runtime is available and the Maven Wrapper is the build tool for the workspace.
  - **Changes to Make**: Validate environment; no project file changes.
  - **Verification**: Use the JDK discovery and wrapper inspection results; build tool path is the workspace Maven Wrapper entrypoint.

- Step 2: Setup Baseline
  - **Rationale**: The current project JDK level is 17, but the workspace does not expose a base JDK installation, so no baseline compile/test run can be executed.
  - **Changes to Make**: Skip baseline with a recorded note because the base JDK is unavailable.
  - **Verification**: `mvnw.cmd clean compile test-compile -q && mvnw.cmd clean test -q` is not executable because JDK 17 is not found in the environment; skip and note this in the progress log.

- Step 3: Upgrade Java Runtime Target
  - **Rationale**: The project metadata needs both the Java target version property and the Spring Boot parent dependency line upgraded. The Boot 3.3.4 test scanner cannot parse Java 25 class files, so this step aligns the framework with the requested Java 25 runtime target.
  - **Changes to Make**: Apply all Dependency Changes and Configuration Changes from Impact Analysis by updating `pom.xml` from `java.version` 17 to 25 and `spring-boot-starter-parent` 3.3.4 to 3.5.16.
  - **Verification**: `mvnw.cmd clean test-compile -q` using JDK 25, expecting compilation success for main and test sources.

- Step 4: Final Validation
  - **Rationale**: Confirm the requested upgrade satisfies the Java 25 target and that the full test suite remains green on the latest JDK runtime.
  - **Changes to Make**: No additional source changes expected.
  - **Verification**: `mvnw.cmd clean test -q` using JDK 25, expecting 100% test pass rate.

- Step 5: CVE Validation & Fix
  - **Rationale**: Confirm no dependency version overrides or direct dependencies require vulnerability remediation.
  - **Changes to Make**: Scan listed direct dependencies; no forced upgrades expected unless a CVE report identifies one.
  - **Verification**: `mvnw.cmd dependency:list -DexcludeTransitive=true` followed by the CVE scan tool and a re-scan verification.
