package com.lojaAX.LojaAX;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LojaAxApplication {

	public static void main(String[] args) {
		SpringApplication.run(LojaAxApplication.class, args);
	}

}
