package com.lojaAX.LojaAX.controller;

import com.lojaAX.LojaAX.model.Produto;
import com.lojaAX.LojaAX.service.ProdutoService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
public class ProdutoController {

    private final ProdutoService produtoService;

    public ProdutoController(ProdutoService produtoService) {
        this.produtoService = produtoService;
    }

    @GetMapping("/produtos")
    public List<Produto> listarProdutosApi(@RequestParam(value = "categoria", required = false) String categoria) {
        if (categoria == null || categoria.isBlank() || categoria.equalsIgnoreCase("Todos")) {
            return produtoService.listarProdutos();
        }
        return produtoService.listarProdutosPorCategoria(categoria);
    }

    @GetMapping("/produtos/{id}")
    public ResponseEntity<Produto> buscarProdutoApi(@PathVariable Long id) {
        Produto produto = produtoService.buscarProdutoPorId(id);
        if (produto == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(produto);
    }

    @GetMapping("/categorias")
    public List<String> listarCategoriasApi() {
        return produtoService.listarCategorias();
    }

    @PostMapping("/produtos")
    public ResponseEntity<Produto> criarProdutoApi(@RequestBody Produto produto) {
        Produto criado = produtoService.criarProduto(produto);
        return ResponseEntity.status(HttpStatus.CREATED).body(criado);
    }

    @PutMapping("/produtos/{id}")
    public ResponseEntity<Produto> atualizarProdutoApi(@PathVariable Long id, @RequestBody Produto produto) {
        Produto atualizado = produtoService.atualizarProduto(id, produto);
        return ResponseEntity.ok(atualizado);
    }

    @DeleteMapping("/produtos/{id}")
    public ResponseEntity<Void> excluirProdutoApi(@PathVariable Long id) {
        produtoService.excluirProduto(id);
        return ResponseEntity.noContent().build();
    }
}
