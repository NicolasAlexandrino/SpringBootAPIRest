package com.lojaAX.LojaAX.controller;

import com.lojaAX.LojaAX.model.Produto;
import com.lojaAX.LojaAX.service.ProdutoService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Controller
public class ProdutoViewController {

    private final ProdutoService produtoService;

    public ProdutoViewController(ProdutoService produtoService) {
        this.produtoService = produtoService;
    }

    @GetMapping("/")
    public String index(Model model) {
        model.addAttribute("produtos", produtoService.listarProdutos());
        return "index";
    }

    @GetMapping("/sobre")
    public String sobre() {
        return "sobre";
    }

    @GetMapping("/produtos")
    public String produtos(@RequestParam(value = "categoria", required = false) String categoria,
                            @RequestParam(value = "pesquisa", required = false) String pesquisa,
                            Model model) {
        List<Produto> produtos = produtoService.listarProdutosComFiltro(categoria, pesquisa);
        model.addAttribute("produtos", produtos);
        model.addAttribute("categorias", produtoService.listarCategorias());
        model.addAttribute("categoriaSelecionada", categoria == null || categoria.isBlank() || categoria.equalsIgnoreCase("Todos") ? "Todos" : categoria);
        model.addAttribute("pesquisa", pesquisa == null ? "" : pesquisa);
        return "produtos";
    }

    @GetMapping("/produtos/novo")
    public String novoProduto(Model model) {
        model.addAttribute("produto", new Produto());
        return "novo-produto";
    }

    @PostMapping("/produtos")
    public String criarProdutoWeb(@ModelAttribute Produto produto) {
        produtoService.criarProduto(produto);
        return "redirect:/produtos";
    }

    @GetMapping("/produto/{id}")
    public String detalhe(@PathVariable Long id, Model model) {
        Produto produto = produtoService.buscarProdutoPorId(id);
        if (produto == null) {
            return "redirect:/produtos";
        }

        model.addAttribute("produto", produto);
        return "detalhe";
    }
}
