package com.lojaAX.LojaAX.repository;

import com.lojaAX.LojaAX.model.Produto;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

@Repository
public class ProdutoRepository {

    private final List<Produto> produtos = new ArrayList<>(List.of(
            new Produto(1L, "Notebook AX Ultra 14", "Notebook", "AX Tech", "Notebook leve, com processador moderno e display Full HD.", 4299.00, "https://images.unsplash.com/photo-1517336714731-489689fd1ca8?auto=format&fit=crop&w=800&q=80", 12),
            new Produto(2L, "Computador AX Gamer", "Computador", "AX Tech", "Desktop gamer com potência para jogos e edição multimídia.", 5980.00, "https://images.unsplash.com/photo-1591799264318-7e6ef8ddb7ea?auto=format&fit=crop&w=800&q=80", 7),
            new Produto(3L, "Notebook AX Office Pro", "Notebook", "AX Tech", "Notebook para trabalho com autonomia de bateria e desempenho estável.", 3199.00, "https://images.unsplash.com/photo-1496181133206-80ce9b88a853?auto=format&fit=crop&w=800&q=80", 9),
            new Produto(4L, "Computador AX Studio", "Computador", "AX Tech", "Computador completo para criação, estudos e tarefas do dia a dia.", 3490.00, "https://images.unsplash.com/photo-1587202372634-32705e3bf49c?auto=format&fit=crop&w=800&q=80", 14),
            new Produto(5L, "Notebook AX Creator", "Notebook", "AX Tech", "Notebook com tela premium para edição, design e produtividade.", 5590.00, "https://images.unsplash.com/photo-1525547719571-a2d4ac8945e2?auto=format&fit=crop&w=800&q=80", 5)
    ));

    private Long proximoId = 6L;

    public List<Produto> findAll() {
        return new ArrayList<>(produtos);
    }

    public Produto findById(Long id) {
        for (Produto produto : produtos) {
            if (produto.getId().equals(id)) {
                return produto;
            }
        }
        return null;
    }

    public Produto save(Produto produto) {
        if (produto.getId() == null) {
            produto.setId(proximoId++);
        }
        produtos.add(produto);
        return produto;
    }

    public Produto update(Long id, Produto produtoAtualizado) {
        Produto produto = findById(id);
        if (produto == null) {
            return null;
        }

        produto.setNome(produtoAtualizado.getNome());
        produto.setCategoria(produtoAtualizado.getCategoria());
        produto.setFabricante(produtoAtualizado.getFabricante());
        produto.setDescricao(produtoAtualizado.getDescricao());
        produto.setPreco(produtoAtualizado.getPreco());
        produto.setImagem(produtoAtualizado.getImagem());
        produto.setEstoque(produtoAtualizado.getEstoque());

        return produto;
    }

    public boolean delete(Long id) {
        return produtos.removeIf(produto -> produto.getId().equals(id));
    }

    public void atualizarEstoque(Long id, Integer novoEstoque) {
        Produto produto = findById(id);
        if (produto != null) {
            produto.setEstoque(novoEstoque);
        }
    }

    public List<Produto> findByCategoria(String categoria) {
        if (categoria == null || categoria.isBlank() || categoria.equalsIgnoreCase("Todos")) {
            return findAll();
        }

        List<Produto> resultado = new ArrayList<>();
        for (Produto produto : produtos) {
            if (produto.getCategoria().equalsIgnoreCase(categoria)) {
                resultado.add(produto);
            }
        }
        return resultado;
    }

    public List<Produto> findByCategoriaAndPesquisa(String categoria, String pesquisa) {
        List<Produto> resultado = findByCategoria(categoria);
        if (pesquisa == null || pesquisa.isBlank()) {
            return resultado;
        }

        String termo = pesquisa.trim().toLowerCase();
        List<Produto> filtrados = new ArrayList<>();
        for (Produto produto : resultado) {
            String texto = (produto.getNome() + " " + produto.getDescricao() + " " + produto.getFabricante() + " " + produto.getCategoria())
                    .toLowerCase();
            if (texto.contains(termo)) {
                filtrados.add(produto);
            }
        }
        return filtrados;
    }
}
