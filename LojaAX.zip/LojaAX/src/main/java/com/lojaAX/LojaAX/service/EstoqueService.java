package com.lojaAX.LojaAX.service;

import com.lojaAX.LojaAX.model.Produto;
import com.lojaAX.LojaAX.repository.ProdutoRepository;
import org.springframework.stereotype.Service;

@Service
public class EstoqueService {

    private final ProdutoRepository produtoRepository;

    public EstoqueService(ProdutoRepository produtoRepository) {
        this.produtoRepository = produtoRepository;
    }

    public boolean temEstoque(Long produtoId) {
        Produto produto = produtoRepository.findById(produtoId);
        return produto != null && produto.getEstoque() != null && produto.getEstoque() > 0;
    }

    public boolean podeVender(Long produtoId) {
        return temEstoque(produtoId);
    }

    public void validarVenda(Long produtoId) {
        Produto produto = produtoRepository.findById(produtoId);

        if (produto == null) {
            throw new IllegalArgumentException("Produto não encontrado.");
        }

        if (produto.getEstoque() == null || produto.getEstoque() <= 0) {
            throw new IllegalStateException("Produto fora de estoque. Venda não autorizada.");
        }
    }
}
