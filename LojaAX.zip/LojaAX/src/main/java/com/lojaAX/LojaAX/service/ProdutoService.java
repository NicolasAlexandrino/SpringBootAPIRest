package com.lojaAX.LojaAX.service;

import com.lojaAX.LojaAX.model.Produto;
import com.lojaAX.LojaAX.repository.ProdutoRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProdutoService {

    private final ProdutoRepository produtoRepository;

    public ProdutoService(ProdutoRepository produtoRepository) {
        this.produtoRepository = produtoRepository;
    }

    public List<Produto> listarProdutos() {
        return produtoRepository.findAll();
    }

    public List<Produto> listarProdutosPorCategoria(String categoria) {
        return produtoRepository.findByCategoria(categoria);
    }

    public List<Produto> listarProdutosComFiltro(String categoria, String pesquisa) {
        return produtoRepository.findByCategoriaAndPesquisa(categoria, pesquisa);
    }

    public Produto buscarProdutoPorId(Long id) {
        return produtoRepository.findById(id);
    }

    public List<String> listarCategorias() {
        return List.of("Todos", "Notebook", "Computador");
    }

    public Produto criarProduto(Produto produto) {
        validarProduto(produto);
        return produtoRepository.save(produto);
    }

    public Produto atualizarProduto(Long id, Produto produtoAtualizado) {
        Produto produtoExistente = produtoRepository.findById(id);
        if (produtoExistente == null) {
            throw new IllegalArgumentException("Produto não encontrado.");
        }

        validarProduto(produtoAtualizado);
        return produtoRepository.update(id, produtoAtualizado);
    }

    public void excluirProduto(Long id) {
        boolean removido = produtoRepository.delete(id);
        if (!removido) {
            throw new IllegalArgumentException("Produto não encontrado.");
        }
    }

    public double aplicarDesconto(Produto produto, double percentualDesconto) {
        if (produto == null) {
            throw new IllegalArgumentException("Produto não informado.");
        }

        if (produto.getPreco() < 10.00) {
            throw new IllegalArgumentException("Produtos com preço menor que R$ 10,00 não podem receber desconto.");
        }

        if (percentualDesconto < 0 || percentualDesconto > 50.0) {
            throw new IllegalArgumentException("O percentual de desconto deve estar entre 0% e 50%.");
        }

        return produto.getPreco() - (produto.getPreco() * percentualDesconto / 100.0);
    }

    private void validarProduto(Produto produto) {
        if (produto == null) {
            throw new IllegalArgumentException("Produto não informado.");
        }

        if (produto.getNome() == null || produto.getNome().isBlank()) {
            throw new IllegalArgumentException("Nome do produto é obrigatório.");
        }

        if (produto.getPreco() == null || produto.getPreco() < 0) {
            throw new IllegalArgumentException("Preço do produto deve ser maior ou igual a zero.");
        }

        if (produto.getEstoque() == null || produto.getEstoque() < 0) {
            throw new IllegalArgumentException("Estoque do produto deve ser maior ou igual a zero.");
        }
    }
}
