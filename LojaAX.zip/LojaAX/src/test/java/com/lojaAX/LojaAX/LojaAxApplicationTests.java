package com.lojaAX.LojaAX;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.lojaAX.LojaAX.model.Produto;
import com.lojaAX.LojaAX.repository.ProdutoRepository;
import com.lojaAX.LojaAX.service.EstoqueService;
import com.lojaAX.LojaAX.service.ProdutoService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
class LojaAxApplicationTests {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private EstoqueService estoqueService;

    @Autowired
    private ProdutoService produtoService;

    @Autowired
    private ProdutoRepository produtoRepository;

    @Autowired
    private ObjectMapper objectMapper;

    @Test
    void apiShouldListProductsAndCategories() throws Exception {
        mockMvc.perform(get("/api/produtos"))
                .andExpect(status().isOk())
                .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON));

        mockMvc.perform(get("/api/categorias"))
                .andExpect(status().isOk())
                .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON));
    }

    @Test
    void apiShouldFilterNotebookCategory() throws Exception {
        mockMvc.perform(get("/api/produtos").param("categoria", "Notebook"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].categoria").value("Notebook"));
    }

    @Test
    void estoqueServiceShouldCheckAvailableProductStock() {
        assertTrue(estoqueService.temEstoque(1L));
        assertFalse(estoqueService.temEstoque(999L));
    }

    @Test
    void estoqueServiceShouldRejectSaleWhenStockIsBelowOne() {
        produtoRepository.atualizarEstoque(1L, 0);

        assertThrows(IllegalStateException.class, () -> estoqueService.validarVenda(1L));

        produtoRepository.atualizarEstoque(1L, 12);
    }

    @Test
    void produtoApiShouldSupportCreateUpdateAndDelete() throws Exception {
        Produto novoProduto = new Produto(null, "Produto REST", "Notebook", "AX Tech",
                "Produto criado pela API REST", 2000.0, "imagem.png", 5);

        String createdJson = mockMvc.perform(post("/api/produtos")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(novoProduto)))
                .andExpect(status().isCreated())
                .andReturn()
                .getResponse()
                .getContentAsString();

        Produto produtoCriado = objectMapper.readValue(createdJson, Produto.class);

        Produto atualizado = new Produto();
        atualizado.setNome("Produto REST Atualizado");
        atualizado.setCategoria("Computador");
        atualizado.setFabricante("AX Tech");
        atualizado.setDescricao("Produto atualizado pela API REST");
        atualizado.setPreco(2500.0);
        atualizado.setImagem("imagem-nova.png");
        atualizado.setEstoque(10);

        mockMvc.perform(put("/api/produtos/{id}", produtoCriado.getId())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(atualizado)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.nome").value("Produto REST Atualizado"));

        mockMvc.perform(delete("/api/produtos/{id}", produtoCriado.getId()))
                .andExpect(status().isNoContent());
    }

    @Test
    void webPagesShouldExposeAboutPageAndProductSearchFilterAndProductForm() throws Exception {
        mockMvc.perform(get("/sobre"))
                .andExpect(status().isOk())
                .andExpect(view().name("sobre"));

        mockMvc.perform(get("/produtos").param("pesquisa", "AX"))
                .andExpect(status().isOk())
                .andExpect(view().name("produtos"));

        mockMvc.perform(get("/produtos/novo"))
                .andExpect(status().isOk())
                .andExpect(view().name("novo-produto"));
    }

    @Test
    void produtoServiceShouldRejectDiscountForLowPriceProduct() {
        Produto produtoBarato = new Produto();
        produtoBarato.setPreco(9.99);

        assertThrows(IllegalArgumentException.class,
                () -> produtoService.aplicarDesconto(produtoBarato, 10.0));
    }
}

